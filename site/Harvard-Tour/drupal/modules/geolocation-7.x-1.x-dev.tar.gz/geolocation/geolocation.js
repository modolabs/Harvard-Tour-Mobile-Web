/**
 * @file
 * Javascript code  for Geolocation Field.
 */
