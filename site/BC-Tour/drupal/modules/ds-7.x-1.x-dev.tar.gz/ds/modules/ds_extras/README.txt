
The extras module contains functionality that is not often used. It holds
following functionality:

 - switch view modes: switch view mode on a per node basis
 - block region: add regions which will be exposed as blocks.
 - Views displays: render views into a different layout.
     Important: If you are creating new ds fields for vd,
     check ds_vd_render_title_field() how to return the content.
 
Any other functionality will be included in this module.